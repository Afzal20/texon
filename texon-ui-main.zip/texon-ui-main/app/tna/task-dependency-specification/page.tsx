"use client"

import * as React from "react"
import { TnAWorkspace } from "../tna-workspace"
import { getTasks } from "@/lib/api/tna"

export default function TaskDependencySpecificationPage() {
  const [data, setData] = React.useState<{ metrics?: { label: string; value: string; note: string; trend: "up" | "down" | "neutral" }[]; rows?: string[][] }>({})
  const [rawItems, setRawItems] = React.useState<Record<string, unknown>[]>([])

  React.useEffect(() => {
    getTasks().then((res) => {
      const items = Array.isArray(res.data?.results) ? res.data.results : Array.isArray(res.data) ? res.data : []
      setRawItems(items as Record<string, unknown>[])
      if (items.length > 0) {
        setData({
          rows: items.slice(0, 4).map((i: any) => [i.task_id ?? i.id?.toString(), i.title ?? "-", i.depends_on ?? "-", i.status ?? "-", i.priority ?? "Normal", i.due_date ?? "-"]),
        })
      }
    }).catch(() => {})
  }, [])

  return <TnAWorkspace module="task-dependency-specification" metrics={data.metrics} rows={data.rows} rawItems={rawItems} />
}
